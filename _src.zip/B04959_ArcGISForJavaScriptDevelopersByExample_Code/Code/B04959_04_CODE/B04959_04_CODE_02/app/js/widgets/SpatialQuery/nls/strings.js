define({
    root: {
        widgetTitle: "Significant earthquakes in History",
        description: "All earthquakes with magnitude greater than 6"
    },
	"zh-cn": true, 
	"de-at" : true
})