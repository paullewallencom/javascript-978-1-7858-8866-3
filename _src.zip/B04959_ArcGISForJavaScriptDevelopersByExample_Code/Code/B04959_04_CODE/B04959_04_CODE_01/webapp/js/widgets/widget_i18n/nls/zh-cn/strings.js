define({
    widgetTitle: "我的小工具",
    description: "自定义窗口小部件"
});