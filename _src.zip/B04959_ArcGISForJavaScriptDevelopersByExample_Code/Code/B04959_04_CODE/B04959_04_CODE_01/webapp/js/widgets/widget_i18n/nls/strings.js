define({
    root: {
        widgetTitle: "My Widget",
        description: "A custom widget."
    }
    // add supported locales below:
    , "zh-cn": true
});